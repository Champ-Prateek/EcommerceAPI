﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace thinkbridgeinventory.Models
{
    public class catesubcat
    {
        public int catid { get; set; }
        public int subcatid { get; set; }
        public int productid { get; set; }
    }
    public class category
    {
        public int catId { get; set; }
        public int mstCatId { get; set; }
        public string catName { get; set; }
        public int isDelete { get; set; }
        public string catimg { get; set; }
    }
    public class productstock
    {
        public int Id { get; set; }
        public int catid { get; set; }
        public int subcatid { get; set; }
        public int productid { get; set; }
        public float measurement { get; set; }
        public int stock { get; set; }
        public float price { get; set; }
        public float baseprice { get; set; }
        public int status { get; set; }
        public float discount { get; set; }
        public float discountprice { get; set; }
        public float tax { get; set; }
        public float taxamount { get; set; }
        public float profitpercent { get; set; }
        public float profit { get; set; }
        public float pprice { get; set; }
        public float weight { get; set; }
        public string sku { get; set; }
    }
    public class unitmaster
    {
        public int unitId { get; set; }
        public string unitName { get; set; }
    }
    public class brandmaster
    {
        public int Id { get; set; }
        public string Brandname { get; set; }
        public string brandimg { get; set; }
    }
    public class cart
    {
        public int cartid { get; set; }
        public int custid { get; set; }
        public string email { get; set; }
        public string sessionid { get; set; }
        public int productid { get; set; }
        public string productimg { get; set; }
        public float price { get; set; }
        public int quantity { get; set; }
        public float subtotal { get; set; }
        public DateTime addtime { get; set; }
        public string carttype { get; set; }
        public int isdelete { get; set; }
        public float discount { get; set; }
        public DateTime exptime { get; set; }
        public int offerid { get; set; }
        public float measurement { get; set; }
        public string unit { get; set; }
        public int measureid { get; set; }
        public float tax { get; set; }
        public float taxamount { get; set; }
        public float pprice { get; set; }
        public float profit { get; set; }
        public string sku { get; set; }
    }
    public class userprofile
    {
        public int Id { get; set; }
        public int cartid { get; set; }
        public int productid { get; set; }
        public int quantity { get; set; }
        public string username { get; set; }
        public HttpPostedFileBase profileimg { get; set; }
        public string mobileno { get; set; }
        public string emailid { get; set; }
        public DateTime regdate { get; set; }
        public DateTime dob { get; set; }
        public string agecertificate { get; set; }
        public string password { get; set; }
        public int status { get; set; }
    }
    public class product
    {
        public int id { get; set; }
        public string productName { get; set;}
        public int CatId { get; set;}
        public int subCatId { get; set;}
        public string description { get; set;}
        public int isDelete { get; set;}
        public string image1 { get; set;}
        public string shortDesc1 { get; set;}
        public string modalNo { get; set;}
        public int unitId { get; set;}
        public string skucode { get; set; }
        public int productId { get; set; }
        public int brandid { get; set; }
    }
    public class cartid
    {
        public int Id { get; set; }
    }
    public class order
    {
        public int action { get; set; }
        public string emailid { get; set; }
        public List<cartid> cartid { get; set; }
        public int id { get; set; }
        public int custid { get; set; }
        public string sessionid { get; set; }
        public float price { get; set; }
        public float discount { get; set; }
        public int quantity { get; set; }
        public float subtotal { get; set; }
        public DateTime orderdate { get; set; }
        public string couponcode { get; set; }
        public string address { get; set; }
        public string landmark { get; set; }
        public int cityid { get; set; }
        public int stateid { get; set; }
        public string pincode { get; set; }
        public int status { get; set; }
        public string paymenttype { get; set; }
        public string invoiceno { get; set; }
        public float measurement { get; set; }
        public string unit { get; set; }
        public int measureid { get; set; }
        public float tax { get; set; }
        public float taxamount { get; set; }
        public string mobile { get; set; }
        public string email { get; set; }
        public string name { get; set; }
    }
    public class useraddress
    {
        public int Id { get; set; }
        public int custid { get; set; }
        public string address { get; set; }
        public string landmark { get; set; }
        public string pincode { get; set; }
        public int cityid { get; set; }
        public int stateid { get; set; }
        public string mobileno { get; set; }
        public int status { get; set; }
        public string Name { get; set; }
        public string emailid { get; set; }
        public string email { get; set; }
        public string userid { get; set; }
        public string statename { get; set; }
        public string cityname { get; set; }
    }
    public class holderror
    {
        public void errormsg(string error, string page, string controller)
        {
            SqlHelper.ExecuteNonQuery(Connection.connection, CommandType.Text, "insert into error_log values ('" + error.Replace("'", "") + "', '" + page + "', '" + controller + "', GETDATE())");
        }
    }
}