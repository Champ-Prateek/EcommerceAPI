﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;

namespace thinkbridgeinventory
{
    public class Connection
    {
        #region connection
        public static string connection
        {
            get
            {
                return ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
            }
        }
        #endregion region connection
    }
}