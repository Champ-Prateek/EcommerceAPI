﻿using thinkbridgeinventory.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.Http;
using System.Web;
using System.Net.Http;
using System.Net;
using System.Threading.Tasks;
using System.Collections.Specialized;
using System.Web.Configuration;
using System.IO;
using System.Collections.Generic;
using System.Net.Http.Headers;
using System.Linq;

namespace thinkbridgeinventory.Controllers
{
    [RoutePrefix("setting/api")]
    public class settingController : ApiController
    {
        //GET: setting
        holderror he = new holderror();
        [HttpPost]
        [Route("signup")]
        public async Task<JObject> signup()
        {
            JObject obj = new JObject();
            DataSet ds = new DataSet();
            // Check whether the POST operation is MultiPart?
            if (!Request.Content.IsMimeMultipartContent())
            {
                throw new HttpResponseException(HttpStatusCode.UnsupportedMediaType);
            }

            // Prepare CustomMultipartFormDataStreamProvider in which our multipart form
            // data will be loaded.
            string fileSaveLocation = "F:\\prateek\\profession\\projects\\thinkbridgeinventory\\thinkbridgeinventory\\images\\profile";
            CustomMultipartFormDataStreamProvider provider = new CustomMultipartFormDataStreamProvider(fileSaveLocation);
            List<string> files = new List<string>();
            try
            {
                if (!Directory.Exists(fileSaveLocation))
                {
                    Directory.CreateDirectory(fileSaveLocation);
                }
                await Request.Content.ReadAsMultipartAsync(provider);
                string finalpath = string.Empty;
                ds = SqlHelper.ExecuteDataset(Connection.connection, CommandType.StoredProcedure, "Loginuser", new SqlParameter("@name", provider.FormData["username"]), new SqlParameter("@dob", Convert.ToDateTime(provider.FormData["dob"])), new SqlParameter("@mobileno", provider.FormData["mobileno"]), new SqlParameter("@emailid", provider.FormData["emailid"]), new SqlParameter("@Password", provider.FormData["password"]), new SqlParameter("@profileimg", finalpath), new SqlParameter("@action", 2));
                foreach (MultipartFileData file in provider.FileData)
                {
                    var df = file.LocalFileName.Split('\\');
                    files.Add(Path.GetFileName(file.LocalFileName));
                    string filename = df[df.Length - 1].Split('.')[0] + Guid.NewGuid().ToString() + "." + df[df.Length - 1].Split('.')[1];
                    finalpath = Path.Combine(fileSaveLocation, filename);
                    if (File.Exists(finalpath))
                    {
                        File.Delete(finalpath);
                    }
                    File.Move(file.LocalFileName, finalpath);
                    finalpath = "../images/profile/" + filename;
                }
                if (!string.IsNullOrEmpty(finalpath) && Convert.ToInt32(ds.Tables[0].Rows[0]["result"]) == 1)
                {
                    SqlHelper.ExecuteNonQuery(Connection.connection, CommandType.Text, "update userprofile set profileimg = '" + finalpath + "' where Id = " + ds.Tables[0].Rows[0]["id"] + "");
                }
            }
            catch (Exception ex)
            {
                he.errormsg(ex.Message, "signup", "setting");
                obj.Add("result", "0");
                obj.Add("messsage", ex.Message);
            }
            if (Convert.ToInt32(ds.Tables[0].Rows[0]["result"]) == 1)
            {
                obj.Add("result", "1");
                obj.Add("message", "Successfully Registered");
            }
            else if (Convert.ToInt32(ds.Tables[0].Rows[0]["result"]) == 2)
            {
                obj.Add("result", "2");
                obj.Add("message", "Already Exist");
            }
            return obj;
        }

        [Route("addaddress")]
        [HttpPost]
        public JObject addaddress(useraddress ua)
        {
            JObject obj = new JObject();
            try
            {
                DataSet ds = SqlHelper.ExecuteDataset(Connection.connection, CommandType.StoredProcedure, "Loginuser", new SqlParameter("@address", ua.address), new SqlParameter("@landmark", ua.landmark), new SqlParameter("@pincode", ua.pincode), new SqlParameter("@cityid", ua.cityid), new SqlParameter("@stateid", ua.stateid), new SqlParameter("@Name", ua.Name), new SqlParameter("@emailid", ua.emailid), new SqlParameter("@email", ua.email), new SqlParameter("@action", 6), new SqlParameter("@mobileno", ua.mobileno));
                if (Convert.ToInt32(ds.Tables[0].Rows[0]["result"]) == 1)
                {
                    obj.Add("result", ds.Tables[0].Rows[0]["result"].ToString());
                    obj.Add("messsage", "Address Added Successfully");
                }
                else if (Convert.ToInt32(ds.Tables[0].Rows[0]["result"]) == 2)
                {
                    obj.Add("result", ds.Tables[0].Rows[0]["result"].ToString());
                    obj.Add("messsage", "Address Already Exist");
                }
                else if (Convert.ToInt32(ds.Tables[0].Rows[0]["result"]) == 3)
                {
                    obj.Add("result", ds.Tables[0].Rows[0]["result"].ToString());
                    obj.Add("messsage", "Invalid User Id");
                }
            }
            catch (SqlException ex)
            {
                he.errormsg(ex.Message, "addaddress", "setting");
                obj.Add("result", "0");
                obj.Add("messsage", ex.Message);
            }
            return obj;
        }
        [Route("login")]
        [HttpPost]
        public JObject login(userprofile up)
        {
            JObject obj = new JObject();
            try
            {
                DataSet ds = SqlHelper.ExecuteDataset(Connection.connection, CommandType.StoredProcedure, "Loginuser", new SqlParameter("@Password", up.password), new SqlParameter("@emailid", up.emailid), new SqlParameter("@action", 1));
                if (Convert.ToInt32(ds.Tables[0].Rows[0]["result"]) == 1)
                {
                    obj.Add("result", ds.Tables[0].Rows[0]["result"].ToString());
                    obj.Add("Type", ds.Tables[0].Rows[0]["Type"].ToString());
                    obj.Add("Id", ds.Tables[0].Rows[0]["Id"].ToString());
                    obj.Add("email", ds.Tables[0].Rows[0]["emailid"].ToString());
                    obj.Add("messsage", "Login Successfully");
                }
                else if (Convert.ToInt32(ds.Tables[0].Rows[0]["result"]) == 2)
                {
                    obj.Add("result", ds.Tables[0].Rows[0]["result"].ToString());
                    obj.Add("messsage", "Invalid Account");
                }
            }
            catch (SqlException ex)
            {
                he.errormsg(ex.Message, "Login", "setting");
                obj.Add("result", "0");
                obj.Add("messsage", ex.Message);
            }
            return obj;
        }
        [Route("getstate")]
        [HttpGet]
        public JObject getstate()
        {
            JObject obj = new JObject();
            DataSet ds = null;
            try
            {
                ds = SqlHelper.ExecuteDataset(Connection.connection, CommandType.Text, "select 1 as result, * from state_master where status = 1");
            }
            catch (SqlException ex)
            {
                he.errormsg(ex.Message, "getstate", "setting");
                ds = SqlHelper.ExecuteDataset(Connection.connection, CommandType.Text, "Select 0 as result, '" + ex.Message + "' as messsage");
            }
            ds.Tables[0].TableName = "States";
            obj = JObject.FromObject(ds);
            return obj;
        }
        [HttpPost]
        [Route("getcity")]
        public JObject getcity(useraddress ua)
        {
            JObject obj = new JObject();
            DataSet ds = null;
            try
            {
                ds = SqlHelper.ExecuteDataset(Connection.connection, CommandType.Text, "select 1 as result, * from City_Master where status = 1 and State_Id = " + ua.stateid + "");
            }
            catch (SqlException ex)
            {
                he.errormsg(ex.Message, "getcity", "setting");
                ds = SqlHelper.ExecuteDataset(Connection.connection, CommandType.Text, "Select 0 as result, '" + ex.Message + "' as messsage");
            }
            ds.Tables[0].TableName = "city";
            obj = JObject.FromObject(ds);
            return obj;
        }

        [HttpPost]
        [Route("getaddress")]
        public JObject getaddress(useraddress ua)
        {
            JObject obj = new JObject();
            DataSet ds = null;
            try
            {
                ds = SqlHelper.ExecuteDataset(Connection.connection, CommandType.StoredProcedure, "Loginuser", new SqlParameter("@action", 7), new SqlParameter("@emailid", ua.emailid));
            }
            catch (SqlException ex)
            {
                he.errormsg(ex.Message, "getaddress", "setting");
                ds = SqlHelper.ExecuteDataset(Connection.connection, CommandType.Text, "Select 0 as result, '" + ex.Message + "' as messsage");
            }
            ds.Tables[0].TableName = "address";
            obj = JObject.FromObject(ds);
            return obj;
        }

        [HttpPost]
        [Route("removeaddress")]
        public JObject removeaddress(useraddress ua)
        {
            JObject obj = new JObject();
            try
            {
                DataSet ds = SqlHelper.ExecuteDataset(Connection.connection, CommandType.StoredProcedure, "Loginuser", new SqlParameter("@action", 8), new SqlParameter("@emailid", ua.emailid), new SqlParameter("@Id", ua.Id));
                if (Convert.ToInt32(ds.Tables[0].Rows[0]["result"]) == 1)
                {
                    obj.Add("result", ds.Tables[0].Rows[0]["result"].ToString());
                    obj.Add("messsage", "Address Removed");
                }
                else if (Convert.ToInt32(ds.Tables[0].Rows[0]["result"]) == 2)
                {
                    obj.Add("result", ds.Tables[0].Rows[0]["result"].ToString());
                    obj.Add("messsage", "Invalid User-Id");
                }
            }
            catch (SqlException ex)
            {
                he.errormsg(ex.Message, "removeaddress", "setting");
                obj.Add("result", "0");
                obj.Add("messsage", ex.Message);
            }
            return obj;
        }

        public class CustomMultipartFormDataStreamProvider : MultipartFormDataStreamProvider
        {
            public CustomMultipartFormDataStreamProvider(string path) : base(path) { }

            public override string GetLocalFileName(HttpContentHeaders headers)
            {
                return headers.ContentDisposition.FileName.Replace("\"", string.Empty);
            }
        }
    }
}