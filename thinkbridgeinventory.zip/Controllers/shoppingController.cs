﻿using thinkbridgeinventory.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.Http;

namespace thinkbridgeinventory.Controllers
{
    [RoutePrefix("shopping/api")]
    public class shoppingController : ApiController
    {
        holderror he = new holderror();
        #region cart
        [Route("cartlist")]
        [HttpPost]
        public JObject cartlist(cart ct)
        {
            JObject obj = new JObject();
            DataSet ds = null;
            try
            {
                ds = SqlHelper.ExecuteDataset(Connection.connection, CommandType.StoredProcedure, "sp_managecart", new SqlParameter("@sessionid", ct.sessionid), new SqlParameter("@emailid", ct.email), new SqlParameter("@action", 1));
            }
            catch (SqlException ex)
            {
                ds = SqlHelper.ExecuteDataset(Connection.connection, CommandType.Text, "Select 0 as result, '" + ex.Message + "' as messsage");
            }
            ds.Tables[0].TableName = "cartlist";
            obj = JObject.FromObject(ds);
            return obj;
        }
        [Route("cartadd")]
        [HttpPost]
        public JObject cartadd(cart ct)
        {
            JObject obj = new JObject();
            try
            {
                DataSet ds = SqlHelper.ExecuteDataset(Connection.connection, CommandType.StoredProcedure, "sp_managecart"
                        , new SqlParameter("@emailid", ct.email)
                        , new SqlParameter("@sessionid", ct.sessionid)
                        , new SqlParameter("@productid", ct.productid)
                        , new SqlParameter("@quantity", ct.quantity)
                        , new SqlParameter("@discount", ct.discount)
                        , new SqlParameter("@measureid", ct.measureid)
                        , new SqlParameter("@carttype", ct.carttype)
                        , new SqlParameter("@action", 2)
                        );
                if (Convert.ToInt32(ds.Tables[0].Rows[0]["result"]) == 1)
                {
                    obj.Add("result", ds.Tables[0].Rows[0]["result"].ToString());
                    obj.Add("messsage", "Item Added In Cart");
                }
            }
            catch (SqlException ex)
            {
                he.errormsg(ex.Message, "cartadd", "Shop");
                obj.Add("result", "0");
                obj.Add("messsage", ex.Message);
            }
            return obj;
        }
        [Route("cartremove")]
        [HttpPost]
        public JObject cartremove(cart ct)
        {
            JObject obj = new JObject();
            try
            {
                DataSet ds = SqlHelper.ExecuteDataset(Connection.connection, CommandType.StoredProcedure, "sp_managecart", new SqlParameter("@action", 3), new SqlParameter("@cartid", ct.cartid));
                if (Convert.ToInt32(ds.Tables[0].Rows[0]["result"]) == 1)
                {
                    obj.Add("result", ds.Tables[0].Rows[0]["result"].ToString());
                    obj.Add("messsage", "Item Remove From Cart");
                }
            }
            catch (SqlException ex)
            {
                he.errormsg(ex.Message, "cartremove", "Shop");
                obj.Add("result", "0");
                obj.Add("messsage", ex.Message);
            }
            return obj;
        }
        [Route("updatecart")]
        [HttpPost]
        public JObject updatecart(cart ct)
        {
            JObject obj = new JObject();
            try
            {
                DataSet ds = SqlHelper.ExecuteDataset(Connection.connection, CommandType.StoredProcedure, "sp_managecart", new SqlParameter("@cartid", ct.cartid), new SqlParameter("@quantity", ct.quantity), new SqlParameter("@action", 2));
                if (Convert.ToInt32(ds.Tables[0].Rows[0]["result"]) == 1)
                {
                    obj.Add("result", ds.Tables[0].Rows[0]["result"].ToString());
                    obj.Add("messsage", "Cart Update");
                }
            }
            catch (SqlException ex)
            {
                he.errormsg(ex.Message, "updatecart", "Shop");
                obj.Add("result", "0");
                obj.Add("messsage", ex.Message);
            }
            return obj;
        }
        #endregion

        #region Order
        [HttpPost]
        [Route("placeorder")]
        public JObject placeorder(order od)
        {
            JObject obj = new JObject();
            try
            {
                DataTable carts = new DataTable();
                carts.Columns.Clear();
                carts.Columns.Add("Id");
                DataRow dr = null;
                foreach (var item in od.cartid)
                {
                    dr = carts.NewRow();
                    dr["Id"] = item.Id.ToString();
                    carts.Rows.Add(dr);
                }
                carts.TableName = "cartid";
                DataSet ds = SqlHelper.ExecuteDataset(Connection.connection, CommandType.StoredProcedure, "manageorder", new SqlParameter("@tsubtotal", od.subtotal), new SqlParameter("@cartid", carts), new SqlParameter("@action", od.action), new SqlParameter("@username", od.name), new SqlParameter("@email", od.email), new SqlParameter("@mobile", od.mobile), new SqlParameter("@address", od.address), new SqlParameter("@landmark", od.landmark), new SqlParameter("@cityid", od.cityid), new SqlParameter("@stateid", od.stateid), new SqlParameter("@pincode", od.pincode), new SqlParameter("@emailid", od.emailid));
                if (Convert.ToInt32(ds.Tables[0].Rows[0]["result"]) == 1)
                {
                    obj.Add("result", "1");
                    obj.Add("message", "Order Placed");
                }
            }
            catch (Exception ex)
            {
                obj.Add("result", "0");
                obj.Add("message", ex.Message);
            }
            return obj;
        }

        [HttpPost]
        [Route("getorder")]
        public JObject getorder(userprofile up)
        {
            JObject obj = new JObject();
            DataSet ds = null;
            try
            {
                ds = SqlHelper.ExecuteDataset(Connection.connection, CommandType.StoredProcedure, "manageorder", new SqlParameter("@emailid", up.emailid), new SqlParameter("@action", 1));
            }
            catch (SqlException ex)
            {
                ds = SqlHelper.ExecuteDataset(Connection.connection, CommandType.Text, "Select 0 as result, '" + ex.Message + "' as messsage");
            }
            ds.Tables[0].TableName = "orderlist";
            obj = JObject.FromObject(ds);
            return obj;
        }
        [HttpPost]
        [Route("getorderstatus")]
        public JObject getorderstatus(order od)
        {
            JObject obj = new JObject();
            DataSet ds = null;
            try
            {
                ds = SqlHelper.ExecuteDataset(Connection.connection, CommandType.StoredProcedure, "manageorder", new SqlParameter("@orderid", od.id), new SqlParameter("@action", 6));
            }
            catch (SqlException ex)
            {
                ds = SqlHelper.ExecuteDataset(Connection.connection, CommandType.Text, "Select 0 as result, '" + ex.Message + "' as messsage");
            }
            ds.Tables[0].TableName = "orderstatus";
            obj = JObject.FromObject(ds);
            return obj;
        }

        [HttpPost]
        [Route("orderdetail")]
        public JObject orderdetail(order od)
        {
            JObject obj = new JObject();
            DataSet ds = null;
            try
            {
                ds = SqlHelper.ExecuteDataset(Connection.connection, CommandType.StoredProcedure, "manageorder", new SqlParameter("@orderid", od.id), new SqlParameter("@action", 5));
            }
            catch (SqlException ex)
            {
                ds = SqlHelper.ExecuteDataset(Connection.connection, CommandType.Text, "Select 0 as result, '" + ex.Message + "' as messsage");
            }
            ds.Tables[0].TableName = "orderdetail";
            if (ds.Tables.Count > 1)
            {
                ds.Tables[1].TableName = "orderstatus";
            }
            obj = JObject.FromObject(ds);
            return obj;
        }
        #endregion
    }
}
