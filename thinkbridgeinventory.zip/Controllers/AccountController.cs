﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using Microsoft.AspNet.Identity.Owin;
using Microsoft.Owin.Security;
using Microsoft.Owin.Security.Cookies;
using Microsoft.Owin.Security.OAuth;
using thinkbridgeinventory.Models;
using thinkbridgeinventory.Providers;
using thinkbridgeinventory.Results;
using System.Data;
using Newtonsoft.Json.Linq;
using System.Data.SqlClient;
using System.IO;
using System.Net;
using System.Net.Http.Headers;

namespace thinkbridgeinventory.Controllers
{
    [RoutePrefix("product/api")]
    public class AccountController : ApiController
    {
        holderror he = new holderror();
        #region category
        [Route("addcategory")]
        [HttpPost]
        public async Task<JObject> addcategory()
        {
            JObject obj = new JObject();
            DataSet ds = new DataSet();
            // Check whether the POST operation is MultiPart?
            if (!Request.Content.IsMimeMultipartContent())
            {
                throw new HttpResponseException(HttpStatusCode.UnsupportedMediaType);
            }

            // Prepare CustomMultipartFormDataStreamProvider in which our multipart form
            // data will be loaded.
            string fileSaveLocation = "F:\\prateek\\profession\\projects\\thinkbridgeinventory\\thinkbridgeinventory\\images\\category";
            CustomMultipartFormDataStreamProvider provider = new CustomMultipartFormDataStreamProvider(fileSaveLocation);
            List<string> files = new List<string>();
            try
            {
                if (!Directory.Exists(fileSaveLocation))
                {
                    Directory.CreateDirectory(fileSaveLocation);
                }
                await Request.Content.ReadAsMultipartAsync(provider);
                string finalpath = string.Empty;
                ds = SqlHelper.ExecuteDataset(Connection.connection, CommandType.StoredProcedure, "spMasterCategory", new SqlParameter("@mstCatId", provider.FormData["mstCatId"]), new SqlParameter("@catName", provider.FormData["catName"]), new SqlParameter("@catimg", finalpath), new SqlParameter("@action", 2));
                foreach (MultipartFileData file in provider.FileData)
                {
                    var df = file.LocalFileName.Split('\\');
                    files.Add(Path.GetFileName(file.LocalFileName));
                    string filename = df[df.Length - 1].Split('.')[0] + Guid.NewGuid().ToString() + "." + df[df.Length - 1].Split('.')[1];
                    finalpath = Path.Combine(fileSaveLocation, filename);
                    if (File.Exists(finalpath))
                    {
                        File.Delete(finalpath);
                    }
                    File.Move(file.LocalFileName, finalpath);
                    finalpath = "../images/category/" + filename;
                }
                if (!string.IsNullOrEmpty(finalpath) && Convert.ToInt32(ds.Tables[0].Rows[0]["result"]) == 1)
                {
                    SqlHelper.ExecuteNonQuery(Connection.connection, CommandType.Text, "update tblProductMasterCategory set catimg = '" + finalpath + "' where mstCatId = " + ds.Tables[0].Rows[0]["id"] + "");
                }
            }
            catch (Exception ex)
            {
                he.errormsg(ex.Message, "addcategory", "Account");
                obj.Add("result", "0");
                obj.Add("messsage", ex.Message);
            }
            if (Convert.ToInt32(ds.Tables[0].Rows[0]["result"]) == 1)
            {
                obj.Add("result", "1");
                obj.Add("message", "Successfully Added");
            }
            else if (Convert.ToInt32(ds.Tables[0].Rows[0]["result"]) == 2)
            {
                obj.Add("result", "2");
                obj.Add("message", "Already Exist");
            }
            return obj;
        }


        [Route("getcategory")]
        [HttpPost]
        public JObject getcategory(category ct)
        {
            JObject obj = new JObject();
            DataSet ds = null;
            try
            {
                ds = SqlHelper.ExecuteDataset(Connection.connection, CommandType.StoredProcedure, "spMasterCategory", new SqlParameter("@mstCatId", ct.mstCatId), new SqlParameter("@action", 1));
            }
            catch (SqlException ex)
            {
                he.errormsg(ex.Message, "getcategory", "Account");
                ds = SqlHelper.ExecuteDataset(Connection.connection, CommandType.Text, "Select 0 as result, '" + ex.Message + "' as messsage");
            }
            ds.Tables[0].TableName = "Category";
            if (ds.Tables.Count > 1)
            {
                ds.Tables[1].TableName = "SingleCategory";
            }
            obj = JObject.FromObject(ds);
            return obj;
        }


        [Route("removecategory")]
        [HttpPost]
        public JObject removecategory(category ct)
        {
            JObject obj = new JObject();
            DataSet ds = null;
            try
            {
                ds = SqlHelper.ExecuteDataset(Connection.connection, CommandType.StoredProcedure, "spMasterCategory", new SqlParameter("@mstCatId", ct.mstCatId), new SqlParameter("@action", 3));
            }
            catch (SqlException ex)
            {
                he.errormsg(ex.Message, "removecategory", "Account");
                ds = SqlHelper.ExecuteDataset(Connection.connection, CommandType.Text, "Select 0 as result, '" + ex.Message + "' as messsage");
            }
            ds.Tables[0].TableName = "Category";
            obj = JObject.FromObject(ds);
            return obj;
        }
        #endregion

        #region subcategory
        [Route("addsubcategory")]
        [HttpPost]
        public async Task<JObject> addsubcategory()
        {
            JObject obj = new JObject();
            DataSet ds = new DataSet();
            // Check whether the POST operation is MultiPart?
            if (!Request.Content.IsMimeMultipartContent())
            {
                throw new HttpResponseException(HttpStatusCode.UnsupportedMediaType);
            }

            // Prepare CustomMultipartFormDataStreamProvider in which our multipart form
            // data will be loaded.
            string fileSaveLocation = "F:\\prateek\\profession\\projects\\thinkbridgeinventory\\thinkbridgeinventory\\images\\subcategory";
            CustomMultipartFormDataStreamProvider provider = new CustomMultipartFormDataStreamProvider(fileSaveLocation);
            List<string> files = new List<string>();
            try
            {
                if (!Directory.Exists(fileSaveLocation))
                {
                    Directory.CreateDirectory(fileSaveLocation);
                }
                await Request.Content.ReadAsMultipartAsync(provider);
                string finalpath = string.Empty;
                ds = SqlHelper.ExecuteDataset(Connection.connection, CommandType.StoredProcedure, "spManageChildcategory", new SqlParameter("@catId", provider.FormData["catId"]), new SqlParameter("@mstCatId", provider.FormData["mstCatId"]), new SqlParameter("@catName", provider.FormData["catName"]), new SqlParameter("@catimg", finalpath), new SqlParameter("@action", 2));
                foreach (MultipartFileData file in provider.FileData)
                {
                    var df = file.LocalFileName.Split('\\');
                    files.Add(Path.GetFileName(file.LocalFileName));
                    string filename = df[df.Length - 1].Split('.')[0] + Guid.NewGuid().ToString() + "." + df[df.Length - 1].Split('.')[1];
                    finalpath = Path.Combine(fileSaveLocation, filename);
                    if (File.Exists(finalpath))
                    {
                        File.Delete(finalpath);
                    }
                    File.Move(file.LocalFileName, finalpath);
                    finalpath = "../images/subcategory/" + filename;
                }
                if (!string.IsNullOrEmpty(finalpath) && Convert.ToInt32(ds.Tables[0].Rows[0]["result"]) == 1)
                {
                    SqlHelper.ExecuteNonQuery(Connection.connection, CommandType.Text, "update tblProductCategory set catimg = '" + finalpath + "' where catId = " + ds.Tables[0].Rows[0]["id"] + "");
                }
            }
            catch (Exception ex)
            {
                he.errormsg(ex.Message, "addsubcategory", "Account");
                obj.Add("result", "0");
                obj.Add("messsage", ex.Message);
            }
            if (Convert.ToInt32(ds.Tables[0].Rows[0]["result"]) == 1)
            {
                obj.Add("result", "1");
                obj.Add("message", "Successfully Added");
            }
            else if (Convert.ToInt32(ds.Tables[0].Rows[0]["result"]) == 2)
            {
                obj.Add("result", "2");
                obj.Add("message", "Already Exist");
            }
            return obj;
        }


        [Route("removesubcategory")]
        [HttpPost]
        public JObject removesubcategory(category ct)
        {
            JObject obj = new JObject();
            DataSet ds = null;
            try
            {
                ds = SqlHelper.ExecuteDataset(Connection.connection, CommandType.StoredProcedure, "spManageChildcategory", new SqlParameter("@catId", ct.catId), new SqlParameter("@action", 3));
            }
            catch (SqlException ex)
            {
                he.errormsg(ex.Message, "removesubcategory", "Account");
                ds = SqlHelper.ExecuteDataset(Connection.connection, CommandType.Text, "Select 0 as result, '" + ex.Message + "' as messsage");
            }
            ds.Tables[0].TableName = "Subcategory";
            obj = JObject.FromObject(ds);
            return obj;
        }

        [HttpPost]
        [Route("getsubcategory")]
        public JObject getsubcategory(category ct)
        {
            JObject obj = new JObject();
            DataSet ds = null;
            try
            {
                ds = SqlHelper.ExecuteDataset(Connection.connection, CommandType.StoredProcedure, "spManageChildcategory", new SqlParameter("@catId", ct.catId), new SqlParameter("@action", 1));
            }
            catch (SqlException ex)
            {
                he.errormsg(ex.Message, "getsubcategory", "Account");
                ds = SqlHelper.ExecuteDataset(Connection.connection, CommandType.Text, "Select 0 as result, '" + ex.Message + "' as messsage");
            }
            ds.Tables[0].TableName = "Subcategory";
            if (ds.Tables.Count > 1)
            {
                ds.Tables[1].TableName = "SingleSubcategory";
            }
            obj = JObject.FromObject(ds);
            return obj;
        }
        #endregion

        #region Unit
        [Route("removeunit")]
        [HttpPost]
        public JObject removeunit(unitmaster um)
        {
            JObject obj = new JObject();
            DataSet ds = null;
            try
            {
                ds = SqlHelper.ExecuteDataset(Connection.connection, CommandType.StoredProcedure, "spUnitMaster", new SqlParameter("@unitId", um.unitId), new SqlParameter("@action", 3));
            }
            catch (SqlException ex)
            {
                he.errormsg(ex.Message, "removeunit", "Account");
                ds = SqlHelper.ExecuteDataset(Connection.connection, CommandType.Text, "Select 0 as result, '" + ex.Message + "' as messsage");
            }
            ds.Tables[0].TableName = "Unit";
            obj = JObject.FromObject(ds);
            return obj;
        }

        [Route("addunit")]
        [HttpPost]
        public JObject addunit(unitmaster um)
        {
            JObject obj = new JObject();
            DataSet ds = null;
            try
            {
                ds = SqlHelper.ExecuteDataset(Connection.connection, CommandType.StoredProcedure, "spUnitMaster", new SqlParameter("@unitId", um.unitId), new SqlParameter("@unitName", um.unitName), new SqlParameter("@action", 2));
            }
            catch (SqlException ex)
            {
                he.errormsg(ex.Message, "addunit", "Account");
                ds = SqlHelper.ExecuteDataset(Connection.connection, CommandType.Text, "Select 0 as result, '" + ex.Message + "' as messsage");
            }
            ds.Tables[0].TableName = "Unit";
            obj = JObject.FromObject(ds);
            return obj;
        }
        [HttpPost]
        [Route("getunit")]
        public JObject getunit(unitmaster um)
        {
            JObject obj = new JObject();
            DataSet ds = null;
            try
            {
                ds = SqlHelper.ExecuteDataset(Connection.connection, CommandType.StoredProcedure, "spUnitMaster", new SqlParameter("@unitId", um.unitId), new SqlParameter("@action", 1));
            }
            catch (SqlException ex)
            {
                he.errormsg(ex.Message, "getbrand", "Account");
                ds = SqlHelper.ExecuteDataset(Connection.connection, CommandType.Text, "Select 0 as result, '" + ex.Message + "' as messsage");
            }
            ds.Tables[0].TableName = "Unit";
            obj = JObject.FromObject(ds);
            return obj;
        }
        #endregion


        #region brand
        [Route("addbrand")]
        [HttpPost]
        public async Task<JObject> addbrand()
        {
            JObject obj = new JObject();
            DataSet ds = new DataSet();
            // Check whether the POST operation is MultiPart?
            if (!Request.Content.IsMimeMultipartContent())
            {
                throw new HttpResponseException(HttpStatusCode.UnsupportedMediaType);
            }

            // Prepare CustomMultipartFormDataStreamProvider in which our multipart form
            // data will be loaded.
            string fileSaveLocation = "F:\\prateek\\profession\\projects\\thinkbridgeinventory\\thinkbridgeinventory\\images\\brand";
            CustomMultipartFormDataStreamProvider provider = new CustomMultipartFormDataStreamProvider(fileSaveLocation);
            List<string> files = new List<string>();
            try
            {
                if (!Directory.Exists(fileSaveLocation))
                {
                    Directory.CreateDirectory(fileSaveLocation);
                }
                await Request.Content.ReadAsMultipartAsync(provider);
                string finalpath = string.Empty;
                ds = SqlHelper.ExecuteDataset(Connection.connection, CommandType.StoredProcedure, "sp_managebrand", new SqlParameter("@Id", provider.FormData["Id"]), new SqlParameter("@Brandname", provider.FormData["Brandname"]), new SqlParameter("@brandimg", provider.FormData["brandimg"]), new SqlParameter("@action", 2));
                foreach (MultipartFileData file in provider.FileData)
                {
                    var df = file.LocalFileName.Split('\\');
                    files.Add(Path.GetFileName(file.LocalFileName));
                    string filename = df[df.Length - 1].Split('.')[0] + Guid.NewGuid().ToString() + "." + df[df.Length - 1].Split('.')[1];
                    finalpath = Path.Combine(fileSaveLocation, filename);
                    if (File.Exists(finalpath))
                    {
                        File.Delete(finalpath);
                    }
                    File.Move(file.LocalFileName, finalpath);
                    finalpath = "../images/brand/" + filename;
                }
                if (!string.IsNullOrEmpty(finalpath) && Convert.ToInt32(ds.Tables[0].Rows[0]["result"]) == 1)
                {
                        SqlHelper.ExecuteNonQuery(Connection.connection, CommandType.Text, "update tblbrandmaster set brandimg = '" + finalpath + "' where Id = " + ds.Tables[0].Rows[0]["id"] + "");
                }
            }
            catch (Exception ex)
            {
                he.errormsg(ex.Message, "addbrand", "Account");
                obj.Add("result", "0");
                obj.Add("messsage", ex.Message);
            }
            if (Convert.ToInt32(ds.Tables[0].Rows[0]["result"]) == 1)
            {
                obj.Add("result", "1");
                obj.Add("message", "Successfully Added");
            }
            else if (Convert.ToInt32(ds.Tables[0].Rows[0]["result"]) == 2)
            {
                obj.Add("result", "2");
                obj.Add("message", "Already Exist");
            }
            return obj;
        }


        [Route("removebrand")]
        [HttpPost]
        public JObject removebrand(brandmaster bm)
        {
            JObject obj = new JObject();
            DataSet ds = null;
            try
            {
                ds = SqlHelper.ExecuteDataset(Connection.connection, CommandType.StoredProcedure, "sp_managebrand", new SqlParameter("@Id", bm.Id), new SqlParameter("@action", 3));
            }
            catch (SqlException ex)
            {
                he.errormsg(ex.Message, "removebrand", "Account");
                ds = SqlHelper.ExecuteDataset(Connection.connection, CommandType.Text, "Select 0 as result, '" + ex.Message + "' as messsage");
            }
            ds.Tables[0].TableName = "Brand";
            obj = JObject.FromObject(ds);
            return obj;
        }

        [HttpPost]
        [Route("getbrand")]
        public JObject getbrand(brandmaster bm)
        {
            JObject obj = new JObject();
            DataSet ds = null;
            try
            {
                ds = SqlHelper.ExecuteDataset(Connection.connection, CommandType.StoredProcedure, "sp_managebrand", new SqlParameter("@Id", bm.Id), new SqlParameter("@action", 1));
            }
            catch (SqlException ex)
            {
                he.errormsg(ex.Message, "getbrand", "Account");
                ds = SqlHelper.ExecuteDataset(Connection.connection, CommandType.Text, "Select 0 as result, '" + ex.Message + "' as messsage");
            }
            ds.Tables[0].TableName = "Brand";
            if (ds.Tables.Count > 1)
            {
                ds.Tables[1].TableName = "SingleBrand";
            }
            obj = JObject.FromObject(ds);
            return obj;
        }
        #endregion

        #region productimages
        [Route("addproductimages")]
        public async Task<JObject> addproductimages()
        {
            JObject obj = new JObject();
            DataSet ds = new DataSet();
            // Check whether the POST operation is MultiPart?
            if (!Request.Content.IsMimeMultipartContent())
            {
                throw new HttpResponseException(HttpStatusCode.UnsupportedMediaType);
            }

            // Prepare CustomMultipartFormDataStreamProvider in which our multipart form
            // data will be loaded.
            string fileSaveLocation = "F:\\prateek\\profession\\projects\\thinkbridgeinventory\\thinkbridgeinventory\\images\\product";
            CustomMultipartFormDataStreamProvider provider = new CustomMultipartFormDataStreamProvider(fileSaveLocation);
            List<string> files = new List<string>();
            try
            {
                if (!Directory.Exists(fileSaveLocation))
                {
                    Directory.CreateDirectory(fileSaveLocation);
                }
                await Request.Content.ReadAsMultipartAsync(provider);
                string finalpath = string.Empty;
                ds = SqlHelper.ExecuteDataset(Connection.connection, CommandType.StoredProcedure, "manage_productimage", new SqlParameter("@productid", provider.FormData["productid"]), new SqlParameter("@Id", provider.FormData["Id"]), new SqlParameter("@imagename", provider.FormData["imagename"]), new SqlParameter("@action", 2));
                foreach (MultipartFileData file in provider.FileData)
                {
                    var df = file.LocalFileName.Split('\\');
                    files.Add(Path.GetFileName(file.LocalFileName));
                    string filename = df[df.Length - 1].Split('.')[0] + Guid.NewGuid().ToString() + "." + df[df.Length - 1].Split('.')[1];
                    finalpath = Path.Combine(fileSaveLocation, filename);
                    if (File.Exists(finalpath))
                    {
                        File.Delete(finalpath);
                    }
                    File.Move(file.LocalFileName, finalpath);
                    finalpath = "../images/product/" + filename;
                }
                if (!string.IsNullOrEmpty(finalpath) && Convert.ToInt32(ds.Tables[0].Rows[0]["result"]) == 1)
                {
                    SqlHelper.ExecuteNonQuery(Connection.connection, CommandType.Text, "update productimages set product_image = '" + finalpath + "' where Id = " + ds.Tables[0].Rows[0]["Id"] + "");
                }
            }
            catch (SqlException ex)
            {
                he.errormsg(ex.Message, "addproductimages", "Account");
                ds = SqlHelper.ExecuteDataset(Connection.connection, CommandType.Text, "Select 0 as result, '" + ex.Message + "' as messsage");
            }
            ds.Tables[0].TableName = "Products";
            obj = JObject.FromObject(ds);
            return obj;
        }
        [HttpPost]
        [Route("getproductimages")]
        public JObject getproductimages(product pt)
        {
            JObject obj = new JObject();
            DataSet ds = null;
            try
            {
                ds = SqlHelper.ExecuteDataset(Connection.connection, CommandType.StoredProcedure, "manage_productimage", new SqlParameter("@Id", pt.id), new SqlParameter("@productid", pt.productId), new SqlParameter("@action", 1));
            }
            catch (SqlException ex)
            {
                he.errormsg(ex.Message, "getproductimages", "Account");
                ds = SqlHelper.ExecuteDataset(Connection.connection, CommandType.Text, "Select 0 as result, '" + ex.Message + "' as messsage");
            }
            ds.Tables[0].TableName = "Products";
            obj = JObject.FromObject(ds);
            return obj;
        }
        [HttpPost]
        [Route("removeproductimages")]
        public JObject removeproductimages(product pt)
        {
            JObject obj = new JObject();
            DataSet ds = null;
            try
            {
                ds = SqlHelper.ExecuteDataset(Connection.connection, CommandType.StoredProcedure, "manage_productimage", new SqlParameter("@Id", pt.id), new SqlParameter("@action", 3));
            }
            catch (SqlException ex)
            {
                he.errormsg(ex.Message, "removeproductimages", "Account");
                ds = SqlHelper.ExecuteDataset(Connection.connection, CommandType.Text, "Select 0 as result, '" + ex.Message + "' as messsage");
            }
            ds.Tables[0].TableName = "Products";
            obj = JObject.FromObject(ds);
            return obj;
        }
        #endregion

        #region product
        [Route("addproduct")]
        public async Task<JObject> addproduct()
        {
            JObject obj = new JObject();
            DataSet ds = new DataSet();
            // Check whether the POST operation is MultiPart?
            if (!Request.Content.IsMimeMultipartContent())
            {
                throw new HttpResponseException(HttpStatusCode.UnsupportedMediaType);
            }

            // Prepare CustomMultipartFormDataStreamProvider in which our multipart form
            // data will be loaded.
            string fileSaveLocation = "F:\\prateek\\profession\\projects\\thinkbridgeinventory\\thinkbridgeinventory\\images\\product";
            CustomMultipartFormDataStreamProvider provider = new CustomMultipartFormDataStreamProvider(fileSaveLocation);
            List<string> files = new List<string>();
            try
            {
                if (!Directory.Exists(fileSaveLocation))
                {
                    Directory.CreateDirectory(fileSaveLocation);
                }
                await Request.Content.ReadAsMultipartAsync(provider);
                string finalpath = string.Empty;
                ds = SqlHelper.ExecuteDataset(Connection.connection, CommandType.StoredProcedure, "spProductMaster", new SqlParameter("@productId", provider.FormData["productId"])
                    , new SqlParameter("@productName", provider.FormData["productName"]), new SqlParameter("@CatId", provider.FormData["CatId"]), new SqlParameter("@subCatId", provider.FormData["subCatId"])
                    , new SqlParameter("@description", provider.FormData["description"]), new SqlParameter("@shortDesc1", provider.FormData["shortDesc1"])
                    , new SqlParameter("@brandid", provider.FormData["brandid"]), new SqlParameter("@modalNo", provider.FormData["modalNo"]), new SqlParameter("@unitId", provider.FormData["unitId"])
                    , new SqlParameter("@skucode", provider.FormData["skucode"]), new SqlParameter("@action", 2));
                foreach (MultipartFileData file in provider.FileData)
                {
                    var df = file.LocalFileName.Split('\\');
                    files.Add(Path.GetFileName(file.LocalFileName));
                    string filename = df[df.Length - 1].Split('.')[0] + Guid.NewGuid().ToString() + "." + df[df.Length - 1].Split('.')[1];
                    finalpath = Path.Combine(fileSaveLocation, filename);
                    if (File.Exists(finalpath))
                    {
                        File.Delete(finalpath);
                    }
                    File.Move(file.LocalFileName, finalpath);
                    finalpath = "../images/product/" + filename;
                }
                if (!string.IsNullOrEmpty(finalpath) && Convert.ToInt32(ds.Tables[0].Rows[0]["result"]) == 1)
                {
                    SqlHelper.ExecuteNonQuery(Connection.connection, CommandType.Text, "update tblProductMaster set image1 = '" + finalpath + "' where productId = " + ds.Tables[0].Rows[0]["productId"] + "");
                }
            }
            catch (SqlException ex)
            {
                he.errormsg(ex.Message, "addproduct", "Account");
                ds = SqlHelper.ExecuteDataset(Connection.connection, CommandType.Text, "Select 0 as result, '" + ex.Message + "' as messsage");
            }
            ds.Tables[0].TableName = "Products";
            obj = JObject.FromObject(ds);
            return obj;
        }
        [HttpPost]
        [Route("getproduct")]
        public JObject getproduct(product pt)
        {
            JObject obj = new JObject();
            DataSet ds = null;
            try
            {
                ds = SqlHelper.ExecuteDataset(Connection.connection, CommandType.StoredProcedure, "spProductMaster", new SqlParameter("@productId", pt.productId), new SqlParameter("@action", 1));
            }
            catch (SqlException ex)
            {
                he.errormsg(ex.Message, "getproduct", "Account");
                ds = SqlHelper.ExecuteDataset(Connection.connection, CommandType.Text, "Select 0 as result, '" + ex.Message + "' as messsage");
            }
            ds.Tables[0].TableName = "Products";
            ds.Tables[1].TableName = "Category";
            ds.Tables[2].TableName = "Unit";
            ds.Tables[3].TableName = "brand";
            obj = JObject.FromObject(ds);
            return obj;
        }
        [HttpPost]
        [Route("removeproduct")]
        public JObject removeproduct(product pt)
        {
            JObject obj = new JObject();
            DataSet ds = null;
            try
            {
                ds = SqlHelper.ExecuteDataset(Connection.connection, CommandType.StoredProcedure, "spProductMaster", new SqlParameter("@productId", pt.productId), new SqlParameter("@action", 3));
            }
            catch (SqlException ex)
            {
                he.errormsg(ex.Message, "removeproduct", "Account");
                ds = SqlHelper.ExecuteDataset(Connection.connection, CommandType.Text, "Select 0 as result, '" + ex.Message + "' as messsage");
            }
            ds.Tables[0].TableName = "Products";
            obj = JObject.FromObject(ds);
            return obj;
        }
        [HttpPost]
        [Route("getproductdetail")]
        public JObject getproductdetail(catesubcat csc)
        {
            JObject obj = new JObject();
            DataSet ds = null;
            try
            {
                ds = SqlHelper.ExecuteDataset(Connection.connection, CommandType.Text, "select 1 as result, [dbo].[urlcreater](p.productname) as url, REPLACE(p.image1, '../', 'http://xyz.com/') as proimage, p.*,u.unitName,mstc.catname,cat.catname as childcategory, tbm.brandname from tblProductMaster as p left outer join tblUnitMaster as u on u.unitId = p.unitId left outer join tblProductMasterCategory as mstc on mstc.mstcatid = p.CatId left outer join tblProductCategory as cat on cat.catid = p.subCatId left outer join tblbrandmaster tbm on tbm.Id = p.brandid where p.isDelete = 0 and mstc.isDelete = 0 and cat.isDelete = 0 and p.productId = " + csc.productid + "");
            }
            catch (SqlException ex)
            {
                ds = SqlHelper.ExecuteDataset(Connection.connection, CommandType.Text, "Select 0 as result, '" + ex.Message + "' as messsage");
            }
            ds.Tables[0].TableName = "Productdetail";
            obj = JObject.FromObject(ds);
            return obj;
        }
        #endregion

        #region productstock
        [Route("removeproductstock")]
        [HttpPost]
        public JObject removeproductstock(productstock ps)
        {
            JObject obj = new JObject();
            DataSet ds = null;
            try
            {
                ds = SqlHelper.ExecuteDataset(Connection.connection, CommandType.StoredProcedure, "managemeproductqty", new SqlParameter("@Id", ps.Id), new SqlParameter("@action", 3));
            }
            catch (SqlException ex)
            {
                he.errormsg(ex.Message, "removeproductstock", "Account");
                ds = SqlHelper.ExecuteDataset(Connection.connection, CommandType.Text, "Select 0 as result, '" + ex.Message + "' as messsage");
            }
            ds.Tables[0].TableName = "Stock";
            obj = JObject.FromObject(ds);
            return obj;
        }

        [Route("addproductstock")]
        [HttpPost]
        public JObject addproductstock(productstock ps)
        {
            JObject obj = new JObject();
            DataSet ds = null;
            try
            {
                ds = SqlHelper.ExecuteDataset(Connection.connection, CommandType.StoredProcedure, "managemeproductqty",
                    new SqlParameter("@Id", ps.Id),
        new SqlParameter("@catid", ps.catid),
        new SqlParameter("@subcatid", ps.subcatid),
        new SqlParameter("@productid", ps.productid),
        new SqlParameter("@measurement", ps.measurement),
        new SqlParameter("@stock", ps.stock),
        new SqlParameter("@baseprice", ps.baseprice),
        new SqlParameter("@discount", ps.discount),
        new SqlParameter("@tax", ps.tax),
        new SqlParameter("@profitpercent", ps.profitpercent),
        new SqlParameter("@weight", ps.weight),
        new SqlParameter("@sku", ps.sku),
        new SqlParameter("@action", 2));
            }
            catch (SqlException ex)
            {
                he.errormsg(ex.Message, "addproductstock", "Account");
                ds = SqlHelper.ExecuteDataset(Connection.connection, CommandType.Text, "Select 0 as result, '" + ex.Message + "' as messsage");
            }
            ds.Tables[0].TableName = "Stock";
            obj = JObject.FromObject(ds);
            return obj;
        }
        [HttpPost]
        [Route("getproductstock")]
        public JObject getproductstock(productstock ps)
        {
            JObject obj = new JObject();
            DataSet ds = null;
            try
            {
                ds = SqlHelper.ExecuteDataset(Connection.connection, CommandType.StoredProcedure, "managemeproductqty", new SqlParameter("@Id", ps.Id), new SqlParameter("@action", 1));
            }
            catch (SqlException ex)
            {
                he.errormsg(ex.Message, "getproductstock", "Account");
                ds = SqlHelper.ExecuteDataset(Connection.connection, CommandType.Text, "Select 0 as result, '" + ex.Message + "' as messsage");
            }
            ds.Tables[0].TableName = "productstock";
            obj = JObject.FromObject(ds);
            return obj;
        }
        #endregion

        public class CustomMultipartFormDataStreamProvider : MultipartFormDataStreamProvider
        {
            public CustomMultipartFormDataStreamProvider(string path) : base(path) { }

            public override string GetLocalFileName(HttpContentHeaders headers)
            {
                return headers.ContentDisposition.FileName.Replace("\"", string.Empty);
            }
        }
    }
}
